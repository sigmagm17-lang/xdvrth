# V22 changes
- Mahoraga now renders from a nine-frame transparent pixel-art atlas in Quest 12.
- Six distinct Mahoraga boss techniques: Sword of Extermination, Adaptation Wheel (healing/armor), Ground Slam, Backhand, Adaptive Rush and Flying Slash.
- Boss casts have individual telegraph windows, damage and range; dash immunity, block and perfect parry are handled.
- Added large arrows for coarse-touch devices including iPadOS desktop-site touch detection.
- Preserved V19 walkable quest RPG, 14 quests, XP, cosmetics, plus online arena multiplayer.
- New tests for Mahoraga and existing gameplay regression.

The 6 attacks are boss actions, not six player-use Mahoraga skills; Mahoraga is still an enemy-only boss. This is a fan-made game update that needs to be deployed to GitHub/Render by the user.

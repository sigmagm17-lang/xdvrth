# JJK PIXEL CLASH V22 — FULL QUEST GAME + MAHORAGA BOSS

Play the live website after deploying:
https://vexelbound-online.onrender.com/story (quest adventure)
https://vexelbound-online.onrender.com/arena (multiplayer)

## Deploy
1. Unzip this package.
2. In your existing GitHub repository, upload everything INSIDE this folder to the matching paths in the repository. Keep server.js, package.json and render.yaml at the root; `public/` remains a directory. DO NOT drag the zipped folder or a nested versioned folder into GitHub.
3. Commit changes to `main`.
4. If Render does not auto-deploy, open vexelbound-online > Manual Deploy > Deploy latest commit.
5. Once Live, refresh /story and /arena. If the browser uses cached assets, try a private tab.

## What's actually new
* Approved nine-frame Mahoraga boss sprite in a real transparent atlas.
* Six telegraphed boss actions (Extermination Sword, Adaptation Wheel, Slam, Backhand, Rush, Flying Slash), real damage/range differences, guard/parry/dodge handling, adaptation damage reduction.
* Bigger boss model and V22 cache-busting.
* Quest map, 14 quests, skins, XP, online room-code multiplayer from V19 retained.

Not published automatically; the current website remains unchanged until the files are committed and deployed.
